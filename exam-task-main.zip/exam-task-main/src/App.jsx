import './App.css'

function App() {
  return (
    <>Empty Project</>
  )
}

export default App
